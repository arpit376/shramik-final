<?php
	define('DB_SERVER','localhost');
	define('DB_USERNAME', 'arpit');
	define('DB_PASSWORD', 'arpit');
	define('DB_DATABASE', 'shramik');
	$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE)
?>
